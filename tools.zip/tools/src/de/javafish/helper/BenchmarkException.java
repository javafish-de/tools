package de.javafish.helper;

public class BenchmarkException extends RuntimeException {

    public BenchmarkException(String message) {
        super(message);
    }
}
