package de.javafish.apiaddition;

import java.util.*;

/**
 *
 * @author fmk
 */
@SuppressWarnings("serial")
public class StringList extends ArrayList<String> {
    
}
